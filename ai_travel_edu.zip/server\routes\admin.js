const express = require('express');
const db = require('../db');
const { authenticate, requireAdmin } = require('../middleware/auth');

const router = express.Router();

// 管理员接口都需要认证和管理员权限
router.use(authenticate);
router.use(requireAdmin);

// 获取所有用户
router.get('/users', (req, res) => {
  const users = db.prepare('SELECT id, username, role, created_at FROM users').all();
  res.json(users);
});

// 更新用户角色
router.put('/users/:id', (req, res) => {
  const { role } = req.body;
  const id = req.params.id;

  if (!role || !['user', 'admin'].includes(role)) {
    return res.status(400).json({ error: '无效的角色' });
  }

  db.prepare('UPDATE users SET role = ? WHERE id = ?').run(role, id);
  const user = db.prepare('SELECT id, username, role, created_at FROM users WHERE id = ?').get(id);
  res.json(user);
});

// 删除用户
router.delete('/users/:id', (req, res) => {
  db.prepare('DELETE FROM users WHERE id = ?').run(req.params.id);
  res.json({ message: '删除成功' });
});

// 获取统计数据
router.get('/stats', (req, res) => {
  const userCount = db.prepare('SELECT COUNT(*) as count FROM users').get().count;
  const locationCount = db.prepare('SELECT COUNT(*) as count FROM locations').get().count;
  const todayVisits = db.prepare(`
    SELECT COUNT(DISTINCT user_id) as count 
    FROM play_logs 
    WHERE DATE(played_at) = DATE('now')
  `).get().count;
  
  const popularLocations = db.prepare(`
    SELECT l.name, COUNT(*) as play_count 
    FROM play_logs p 
    JOIN locations l ON p.location_id = l.id 
    GROUP BY l.id 
    ORDER BY play_count DESC 
    LIMIT 5
  `).all();

  res.json({
    userCount,
    locationCount,
    todayVisits,
    popularLocations
  });
});

module.exports = router;
