const express = require('express');
const cors = require('cors');
const path = require('path');
const authRoutes = require('./routes/auth');
const locationRoutes = require('./routes/locations');
const adminRoutes = require('./routes/admin');
const { UPLOAD_DIR } = require('./config');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

// 静态文件服务（上传的音频/图片）
app.use('/uploads', express.static(UPLOAD_DIR));

// Web管理后台
app.use('/admin', express.static(path.join(__dirname, 'public')));

app.use('/api/auth', authRoutes);
app.use('/api/locations', locationRoutes);
app.use('/api/admin', adminRoutes);

app.get('/', (req, res) => {
  res.json({ message: '西南大学校园游览智能讲解APP API', version: '1.0.0' });
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`服务器运行在 http://localhost:${PORT}`);
});
