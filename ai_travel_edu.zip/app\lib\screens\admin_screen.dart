import 'package:flutter/material.dart';
import '../models/user.dart';
import '../models/location.dart';
import '../services/api_service.dart';

class AdminScreen extends StatefulWidget {
  final User user;
  const AdminScreen({super.key, required this.user});

  @override
  State<AdminScreen> createState() => _AdminScreenState();
}

class _AdminScreenState extends State<AdminScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  List<TourLocation> _locations = [];
  List<dynamic> _users = [];
  Map<String, dynamic> _stats = {};
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _loading = true);
    try {
      final locations = await ApiService.getLocations();
      final users = await ApiService.getUsers();
      final stats = await ApiService.getStats();
      setState(() {
        _locations = locations;
        _users = users;
        _stats = stats;
        _loading = false;
      });
    } catch (e) {
      setState(() => _loading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('加载失败: $e')),
        );
      }
    }
  }

  void _showLocationDialog({TourLocation? location}) {
    final nameCtrl = TextEditingController(text: location?.name ?? '');
    final latCtrl = TextEditingController(text: location?.latitude.toString() ?? '');
    final lonCtrl = TextEditingController(text: location?.longitude.toString() ?? '');
    final radiusCtrl = TextEditingController(text: (location?.radius ?? 50).toString());
    final descCtrl = TextEditingController(text: location?.description ?? '');
    final audioCtrl = TextEditingController(text: location?.audioUrl ?? '');
    final imageCtrl = TextEditingController(text: location?.imageUrl ?? '');
    final isEdit = location != null;

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(isEdit ? '编辑讲解点' : '添加讲解点'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: nameCtrl, decoration: const InputDecoration(labelText: '名称 *')),
              TextField(controller: latCtrl, decoration: const InputDecoration(labelText: '纬度 *'), keyboardType: TextInputType.number),
              TextField(controller: lonCtrl, decoration: const InputDecoration(labelText: '经度 *'), keyboardType: TextInputType.number),
              TextField(controller: radiusCtrl, decoration: const InputDecoration(labelText: '触发半径(米)'), keyboardType: TextInputType.number),
              TextField(controller: descCtrl, decoration: const InputDecoration(labelText: '文字介绍'), maxLines: 3),
              TextField(controller: audioCtrl, decoration: const InputDecoration(labelText: '音频URL')),
              TextField(controller: imageCtrl, decoration: const InputDecoration(labelText: '图片URL')),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('取消')),
          ElevatedButton(
            onPressed: () async {
              try {
                if (isEdit) {
                  await ApiService.updateLocation(
                    location!.id,
                    name: nameCtrl.text,
                    latitude: double.tryParse(latCtrl.text),
                    longitude: double.tryParse(lonCtrl.text),
                    radius: double.tryParse(radiusCtrl.text),
                    description: descCtrl.text,
                    audioUrl: audioCtrl.text,
                    imageUrl: imageCtrl.text,
                  );
                } else {
                  await ApiService.createLocation(
                    name: nameCtrl.text,
                    latitude: double.parse(latCtrl.text),
                    longitude: double.parse(lonCtrl.text),
                    radius: double.tryParse(radiusCtrl.text) ?? 50,
                    description: descCtrl.text,
                    audioUrl: audioCtrl.text,
                    imageUrl: imageCtrl.text,
                  );
                }
                if (mounted) Navigator.pop(ctx);
                _loadData();
              } catch (e) {
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('操作失败: $e')),
                  );
                }
              }
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.green, foregroundColor: Colors.white),
            child: Text(isEdit ? '保存' : '创建'),
          ),
        ],
      ),
    );
  }

  void _deleteLocation(TourLocation loc) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('确认删除'),
        content: Text('确定要删除"${loc.name}"吗？'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('取消')),
          ElevatedButton(
            onPressed: () async {
              try {
                await ApiService.deleteLocation(loc.id);
                Navigator.pop(ctx);
                _loadData();
              } catch (e) {
                Navigator.pop(ctx);
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('删除失败: $e')));
              }
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red, foregroundColor: Colors.white),
            child: const Text('删除'),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('管理后台'),
        backgroundColor: Colors.green,
        foregroundColor: Colors.white,
        bottom: TabBar(
          controller: _tabController,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white70,
          indicatorColor: Colors.white,
          tabs: const [
            Tab(icon: Icon(Icons.analytics), text: '统计'),
            Tab(icon: Icon(Icons.place), text: '景点'),
            Tab(icon: Icon(Icons.people), text: '用户'),
          ],
        ),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : TabBarView(
              controller: _tabController,
              children: [
                _buildStatsTab(),
                _buildLocationsTab(),
                _buildUsersTab(),
              ],
            ),
    );
  }

  // 统计面板
  Widget _buildStatsTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              _buildStatCard('注册用户', '${_stats['userCount'] ?? 0}', Icons.people, Colors.blue),
              const SizedBox(width: 12),
              _buildStatCard('讲解景点', '${_stats['locationCount'] ?? 0}', Icons.place, Colors.orange),
            ],
          ),
          const SizedBox(height: 12),
          _buildStatCard('今日访问', '${_stats['todayVisits'] ?? 0}', Icons.today, Colors.green),
          const SizedBox(height: 24),
          const Text('热门景点排行', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          ...(_stats['popularLocations'] as List<dynamic>? ?? []).map(
            (item) => Card(
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: Colors.green,
                  child: Text('${(_stats['popularLocations'] as List).indexOf(item) + 1}', style: const TextStyle(color: Colors.white)),
                ),
                title: Text(item['name']),
                trailing: Text('${item['play_count']} 次', style: const TextStyle(fontWeight: FontWeight.bold)),
              ),
            ),
          ),
          if ((_stats['popularLocations'] as List?)?.isEmpty ?? true)
            Card(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Center(child: Text('暂无播放记录', style: TextStyle(color: Colors.grey.shade500))),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildStatCard(String title, String value, IconData icon, Color color) {
    return Expanded(
      child: Card(
        elevation: 2,
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              Icon(icon, size: 36, color: color),
              const SizedBox(height: 8),
              Text(value, style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: color)),
              const SizedBox(height: 4),
              Text(title, style: TextStyle(fontSize: 14, color: Colors.grey.shade600)),
            ],
          ),
        ),
      ),
    );
  }

  // 景点管理
  Widget _buildLocationsTab() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              const Expanded(child: Text('共 ${0} 个景点', style: TextStyle(fontWeight: FontWeight.bold))),
              ElevatedButton.icon(
                onPressed: () => _showLocationDialog(),
                icon: const Icon(Icons.add),
                label: const Text('添加景点'),
                style: ElevatedButton.styleFrom(backgroundColor: Colors.green, foregroundColor: Colors.white),
              ),
            ],
          ),
        ),
        Expanded(
          child: ListView.builder(
            itemCount: _locations.length,
            itemBuilder: (_, i) {
              final loc = _locations[i];
              return Card(
                margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor: Colors.green.shade100,
                    child: Text('${i + 1}', style: const TextStyle(color: Colors.green)),
                  ),
                  title: Text(loc.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Text(
                    '坐标: ${loc.latitude.toStringAsFixed(4)}, ${loc.longitude.toStringAsFixed(4)}\n'
                    '半径: ${loc.radius.toInt()}米',
                  ),
                  isThreeLine: true,
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.edit, color: Colors.blue),
                        onPressed: () => _showLocationDialog(location: loc),
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete, color: Colors.red),
                        onPressed: () => _deleteLocation(loc),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  // 用户管理
  Widget _buildUsersTab() {
    return ListView.builder(
      itemCount: _users.length,
      itemBuilder: (_, i) {
        final user = _users[i];
        final isAdmin = user['role'] == 'admin';
        return Card(
          margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor: isAdmin ? Colors.orange.shade100 : Colors.blue.shade100,
              child: Icon(isAdmin ? Icons.admin_panel_settings : Icons.person, color: isAdmin ? Colors.orange : Colors.blue),
            ),
            title: Text(user['username'], style: const TextStyle(fontWeight: FontWeight.bold)),
            subtitle: Text('角色: ${isAdmin ? "管理员" : "普通用户"} | ID: ${user['id']}'),
            trailing: PopupMenuButton(
              onSelected: (value) async {
                if (value == 'toggle_role') {
                  final newRole = isAdmin ? 'user' : 'admin';
                  try {
                    await ApiService.updateUserRole(user['id'], newRole);
                    _loadData();
                  } catch (e) {
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('操作失败: $e')));
                  }
                } else if (value == 'delete') {
                  showDialog(
                    context: context,
                    builder: (ctx) => AlertDialog(
                      title: const Text('确认删除'),
                      content: Text('确定要删除用户"${user['username']}"吗？'),
                      actions: [
                        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('取消')),
                        ElevatedButton(
                          onPressed: () async {
                            try {
                              await ApiService.deleteUser(user['id']);
                              Navigator.pop(ctx);
                              _loadData();
                            } catch (e) {
                              Navigator.pop(ctx);
                              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('删除失败: $e')));
                            }
                          },
                          style: ElevatedButton.styleFrom(backgroundColor: Colors.red, foregroundColor: Colors.white),
                          child: const Text('删除'),
                        ),
                      ],
                    ),
                  );
                }
              },
              itemBuilder: (_) => [
                PopupMenuItem(
                  value: 'toggle_role',
                  child: Text(isAdmin ? '设为普通用户' : '设为管理员'),
                ),
                const PopupMenuItem(value: 'delete', child: Text('删除用户', style: TextStyle(color: Colors.red))),
              ],
            ),
          ),
        );
      },
    );
  }
}
