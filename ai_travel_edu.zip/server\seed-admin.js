const bcrypt = require('bcryptjs');
const db = require('./db');

// 创建管理员账号（如果不存在）
const username = 'admin';
const password = 'admin123';

const existing = db.prepare('SELECT id FROM users WHERE username = ?').get(username);
if (existing) {
  console.log('管理员账号已存在，跳过创建');
} else {
  const hashed = bcrypt.hashSync(password, 10);
  db.prepare('INSERT INTO users (username, password, role) VALUES (?, ?, ?)').run(username, hashed, 'admin');
  console.log(`管理员账号创建成功：用户名=${username}，密码=${password}`);
}

// 执行种子数据
require('./seed');
