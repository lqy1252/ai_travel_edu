import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/user.dart';
import '../models/location.dart';

class ApiService {
  // Web/桌面用localhost，Android模拟器改为10.0.2.2，真机改为局域网IP
  static const String baseUrl = 'http://localhost:3000/api';

  static String? _token;

  static void setToken(String token) {
    _token = token;
  }

  static Map<String, String> get _headers {
    final headers = {'Content-Type': 'application/json'};
    if (_token != null) {
      headers['Authorization'] = 'Bearer $_token';
    }
    return headers;
  }

  // 注册
  static Future<User> register(String username, String password) async {
    final response = await http.post(
      Uri.parse('$baseUrl/auth/register'),
      headers: _headers,
      body: jsonEncode({'username': username, 'password': password}),
    );

    if (response.statusCode == 201) {
      final data = jsonDecode(response.body);
      final user = User.fromJson(data['user'], data['token']);
      _token = user.token;
      return user;
    } else {
      final error = jsonDecode(response.body);
      throw Exception(error['error'] ?? '注册失败');
    }
  }

  // 登录
  static Future<User> login(String username, String password) async {
    final response = await http.post(
      Uri.parse('$baseUrl/auth/login'),
      headers: _headers,
      body: jsonEncode({'username': username, 'password': password}),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      final user = User.fromJson(data['user'], data['token']);
      _token = user.token;
      return user;
    } else {
      final error = jsonDecode(response.body);
      throw Exception(error['error'] ?? '登录失败');
    }
  }

  // 获取所有讲解点
  static Future<List<TourLocation>> getLocations() async {
    final response = await http.get(
      Uri.parse('$baseUrl/locations'),
      headers: _headers,
    );

    if (response.statusCode == 200) {
      final List<dynamic> data = jsonDecode(response.body);
      return data.map((json) => TourLocation.fromJson(json)).toList();
    } else {
      throw Exception('获取讲解点失败');
    }
  }

  // 获取单个讲解点
  static Future<TourLocation> getLocation(int id) async {
    final response = await http.get(
      Uri.parse('$baseUrl/locations/$id'),
      headers: _headers,
    );

    if (response.statusCode == 200) {
      return TourLocation.fromJson(jsonDecode(response.body));
    } else {
      throw Exception('获取讲解点详情失败');
    }
  }

  // 记录播放
  static Future<void> logPlay(int locationId) async {
    await http.post(
      Uri.parse('$baseUrl/locations/$locationId/play'),
      headers: _headers,
    );
  }

  // ===== 管理员 API =====

  // 创建讲解点
  static Future<TourLocation> createLocation({
    required String name,
    required double latitude,
    required double longitude,
    double radius = 50,
    String description = '',
    String audioUrl = '',
    String imageUrl = '',
  }) async {
    final response = await http.post(
      Uri.parse('$baseUrl/locations'),
      headers: _headers,
      body: jsonEncode({
        'name': name,
        'latitude': latitude,
        'longitude': longitude,
        'radius': radius,
        'description': description,
        'audio_url': audioUrl,
        'image_url': imageUrl,
      }),
    );

    if (response.statusCode == 201) {
      return TourLocation.fromJson(jsonDecode(response.body));
    } else {
      final error = jsonDecode(response.body);
      throw Exception(error['error'] ?? '创建失败');
    }
  }

  // 更新讲解点
  static Future<TourLocation> updateLocation(int id, {
    String? name,
    double? latitude,
    double? longitude,
    double? radius,
    String? description,
    String? audioUrl,
    String? imageUrl,
  }) async {
    final body = <String, dynamic>{};
    if (name != null) body['name'] = name;
    if (latitude != null) body['latitude'] = latitude;
    if (longitude != null) body['longitude'] = longitude;
    if (radius != null) body['radius'] = radius;
    if (description != null) body['description'] = description;
    if (audioUrl != null) body['audio_url'] = audioUrl;
    if (imageUrl != null) body['image_url'] = imageUrl;

    final response = await http.put(
      Uri.parse('$baseUrl/locations/$id'),
      headers: _headers,
      body: jsonEncode(body),
    );

    if (response.statusCode == 200) {
      return TourLocation.fromJson(jsonDecode(response.body));
    } else {
      final error = jsonDecode(response.body);
      throw Exception(error['error'] ?? '更新失败');
    }
  }

  // 删除讲解点
  static Future<void> deleteLocation(int id) async {
    final response = await http.delete(
      Uri.parse('$baseUrl/locations/$id'),
      headers: _headers,
    );

    if (response.statusCode != 200) {
      final error = jsonDecode(response.body);
      throw Exception(error['error'] ?? '删除失败');
    }
  }

  // 获取统计数据
  static Future<Map<String, dynamic>> getStats() async {
    final response = await http.get(
      Uri.parse('$baseUrl/admin/stats'),
      headers: _headers,
    );

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      throw Exception('获取统计失败');
    }
  }

  // 获取所有用户
  static Future<List<dynamic>> getUsers() async {
    final response = await http.get(
      Uri.parse('$baseUrl/admin/users'),
      headers: _headers,
    );

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      throw Exception('获取用户列表失败');
    }
  }

  // 更新用户角色
  static Future<void> updateUserRole(int userId, String role) async {
    final response = await http.put(
      Uri.parse('$baseUrl/admin/users/$userId'),
      headers: _headers,
      body: jsonEncode({'role': role}),
    );

    if (response.statusCode != 200) {
      final error = jsonDecode(response.body);
      throw Exception(error['error'] ?? '更新失败');
    }
  }

  // 删除用户
  static Future<void> deleteUser(int userId) async {
    final response = await http.delete(
      Uri.parse('$baseUrl/admin/users/$userId'),
      headers: _headers,
    );

    if (response.statusCode != 200) {
      final error = jsonDecode(response.body);
      throw Exception(error['error'] ?? '删除失败');
    }
  }
}
