const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const db = require('../db');
const { authenticate, requireAdmin } = require('../middleware/auth');
const { UPLOAD_DIR, MAX_FILE_SIZE } = require('../config');

const router = express.Router();

// 确保上传目录存在
if (!fs.existsSync(UPLOAD_DIR)) {
  fs.mkdirSync(UPLOAD_DIR, { recursive: true });
}

// Multer 配置
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    const name = `${Date.now()}-${Math.random().toString(36).substring(2, 8)}${ext}`;
    cb(null, name);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: MAX_FILE_SIZE },
  fileFilter: (req, file, cb) => {
    const allowedTypes = [
      'audio/mpeg', 'audio/mp3', 'audio/wav', 'audio/ogg',
      'image/jpeg', 'image/png', 'image/webp', 'image/gif',
    ];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('不支持的文件类型，仅支持音频(mp3/wav/ogg)和图片(jpg/png/webp)'));
    }
  },
});

// ===== 公开接口（需登录） =====

// 获取所有讲解点
router.get('/', (req, res) => {
  const locations = db.prepare('SELECT * FROM locations ORDER BY id').all();
  res.json(locations);
});

// 获取单个讲解点
router.get('/:id', (req, res) => {
  const location = db.prepare('SELECT * FROM locations WHERE id = ?').get(req.params.id);
  if (!location) {
    return res.status(404).json({ error: '讲解点不存在' });
  }
  res.json(location);
});

// 记录播放统计
router.post('/:id/play', authenticate, (req, res) => {
  const location = db.prepare('SELECT id FROM locations WHERE id = ?').get(req.params.id);
  if (!location) {
    return res.status(404).json({ error: '讲解点不存在' });
  }

  db.prepare(`
    INSERT INTO play_logs (user_id, location_id) VALUES (?, ?)
  `).run(req.user.id, req.params.id);

  res.json({ message: '已记录' });
});

// 获取播放统计
router.get('/:id/stats', authenticate, (req, res) => {
  const stats = db.prepare(`
    SELECT COUNT(*) as play_count FROM play_logs WHERE location_id = ?
  `).get(req.params.id);
  res.json(stats);
});

// ===== 管理员接口 =====

// 创建讲解点
router.post('/', authenticate, requireAdmin, (req, res) => {
  const { name, latitude, longitude, radius, description, audio_url, image_url } = req.body;

  if (!name || latitude == null || longitude == null) {
    return res.status(400).json({ error: '名称、经度、纬度为必填项' });
  }

  const result = db.prepare(`
    INSERT INTO locations (name, latitude, longitude, radius, description, audio_url, image_url)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(name, latitude, longitude, radius || 50, description || '', audio_url || '', image_url || '');

  const location = db.prepare('SELECT * FROM locations WHERE id = ?').get(result.lastInsertRowid);
  res.status(201).json(location);
});

// 更新讲解点
router.put('/:id', authenticate, requireAdmin, (req, res) => {
  const { name, latitude, longitude, radius, description, audio_url, image_url } = req.body;
  const id = req.params.id;

  const existing = db.prepare('SELECT * FROM locations WHERE id = ?').get(id);
  if (!existing) {
    return res.status(404).json({ error: '讲解点不存在' });
  }

  db.prepare(`
    UPDATE locations SET
      name = COALESCE(?, name),
      latitude = COALESCE(?, latitude),
      longitude = COALESCE(?, longitude),
      radius = COALESCE(?, radius),
      description = COALESCE(?, description),
      audio_url = COALESCE(?, audio_url),
      image_url = COALESCE(?, image_url)
    WHERE id = ?
  `).run(name, latitude, longitude, radius, description, audio_url, image_url, id);

  const location = db.prepare('SELECT * FROM locations WHERE id = ?').get(id);
  res.json(location);
});

// 删除讲解点
router.delete('/:id', authenticate, requireAdmin, (req, res) => {
  const existing = db.prepare('SELECT * FROM locations WHERE id = ?').get(req.params.id);
  if (!existing) {
    return res.status(404).json({ error: '讲解点不存在' });
  }

  // 删除关联的文件
  if (existing.audio_url) {
    const audioPath = path.join(UPLOAD_DIR, path.basename(existing.audio_url));
    if (fs.existsSync(audioPath)) fs.unlinkSync(audioPath);
  }
  if (existing.image_url) {
    const imgPath = path.join(UPLOAD_DIR, path.basename(existing.image_url));
    if (fs.existsSync(imgPath)) fs.unlinkSync(imgPath);
  }

  db.prepare('DELETE FROM locations WHERE id = ?').run(req.params.id);
  res.json({ message: '删除成功' });
});

// 文件上传接口
router.post('/upload', authenticate, requireAdmin, upload.single('file'), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: '请选择文件' });
  }
  const fileUrl = `/uploads/${req.file.filename}`;
  res.json({ url: fileUrl, filename: req.file.filename });
});

module.exports = router;
