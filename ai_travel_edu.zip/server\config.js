module.exports = {
  JWT_SECRET: 'campus-tour-secret-key-2024',
  UPLOAD_DIR: require('path').join(__dirname, 'uploads'),
  MAX_FILE_SIZE: 10 * 1024 * 1024, // 10MB
};
